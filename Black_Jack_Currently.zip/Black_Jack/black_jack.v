module black_jack (

	//////////// ADC //////////
	//output		          		ADC_CONVST,
	//output		          		ADC_DIN,
	//input 		          		ADC_DOUT,
	//output		          		ADC_SCLK,

	//////////// Audio //////////
	//input 		          		AUD_ADCDAT,
	//inout 		          		AUD_ADCLRCK,
	//inout 		          		AUD_BCLK,
	//output		          		AUD_DACDAT,
	//inout 		          		AUD_DACLRCK,
	//output		          		AUD_XCK,

	//////////// CLOCK //////////
	//input 		          		CLOCK2_50,
	//input 		          		CLOCK3_50,
	//input 		          		CLOCK4_50,
	input 		          		CLOCK_50,

	//////////// SDRAM //////////
	//output		    [12:0]		DRAM_ADDR,
	//output		     [1:0]		DRAM_BA,
	//output		          		DRAM_CAS_N,
	//output		          		DRAM_CKE,
	//output		          		DRAM_CLK,
	//output		          		DRAM_CS_N,
	//inout 		    [15:0]		DRAM_DQ,
	//output		          		DRAM_LDQM,
	//output		          		DRAM_RAS_N,
	//output		          		DRAM_UDQM,
	//output		          		DRAM_WE_N,

	//////////// I2C for Audio and Video-In //////////
	//output		          		FPGA_I2C_SCLK,
	//inout 		          		FPGA_I2C_SDAT,

	//////////// SEG7 //////////
	output		     [6:0]		HEX0,
	output		     [6:0]		HEX1,
	output		     [6:0]		HEX2,
	output		     [6:0]		HEX3,
	//output		     [6:0]		HEX4,
	//output		     [6:0]		HEX5,

	//////////// IR //////////
	//input 		          		IRDA_RXD,
	//output		          		IRDA_TXD,

	//////////// KEY //////////
	input 		     [3:0]		KEY,

	//////////// LED //////////
	output		     [9:0]		LEDR,

	//////////// PS2 //////////
	//inout 		          		PS2_CLK,
	//inout 		          		PS2_CLK2,
	//inout 		          		PS2_DAT,
	//inout 		          		PS2_DAT2,

	//////////// SW //////////
	input 		     [9:0]		SW,

	//////////// Video-In //////////
	//input 		          		TD_CLK27,
	//input 		     [7:0]		TD_DATA,
	//input 		          		TD_HS,
	//output		          		TD_RESET_N,
	//input 		          		TD_VS,

	//////////// VGA //////////
	output		          		VGA_BLANK_N,
	output		     [7:0]		VGA_B,
	output		          		VGA_CLK,
	output		     [7:0]		VGA_G,
	output		          		VGA_HS,
	output		     [7:0]		VGA_R,
	output		          		VGA_SYNC_N,
	output		          		VGA_VS

	//////////// GPIO_0, GPIO_0 connect to GPIO Default //////////
	//inout 		    [35:0]		GPIO_0,

	//////////// GPIO_1, GPIO_1 connect to GPIO Default //////////
	//inout 		    [35:0]		GPIO_1

);

// Turn off all displays.
assign	HEX0		=	7'h00;
assign	HEX1		=	7'h00;
assign	HEX2		=	7'h00;
assign	HEX3		=	7'h00;

// DONE STANDARD PORT DECLARATION ABOVE
/* HANDLE SIGNALS FOR CIRCUIT */
wire clk;
wire rst;

assign clk = CLOCK_50;
assign rst = KEY[0];

wire [9:0]SW_db;

debounce_switches db(
.clk(clk),
.rst(rst),
.SW(SW), 
.SW_db(SW_db)
);

// VGA DRIVER
wire active_pixels; // is on when we're in the active draw space
wire frame_done;
wire [9:0]x; // current x
wire [9:0]y; // current y - 10 bits = 1024 ... a little bit more than we need



/* variables for the asset controller */
reg [9:0] target_x;
reg [9:0] target_y;

reg [8:0] asset_x;
reg [8:0] asset_y;



/* this is where I'm adding the x, y coordinates of player's cards */

reg [9:0]card1P_target_x = 10'd63;
reg [9:0]card1P_target_y = 10'd81;

reg [9:0]card2P_target_x = 10'd82;
reg [9:0]card2P_target_y = 10'd81;

reg [9:0]card3P_target_x = 10'd73;
reg [9:0]card3P_target_y = 10'd57;

reg [9:0]card4P_target_x = 10'd46;
reg [9:0]card4P_target_y = 10'd62;

reg [9:0]card5P_target_x = 10'd100;
reg [9:0]card5P_target_y = 10'd61;



/* this is where I'm adding the x, y coordinates of dealer's cards */

reg [9:0]card1D_target_x = 10'd56;
reg [9:0]card1D_target_y = 10'd9;

reg [9:0]card2D_target_x = 10'd90;
reg [9:0]card2D_target_y = 10'd9;

reg [9:0]card3D_target_x = 10'd73;
reg [9:0]card3D_target_y = 10'd26;

reg [9:0]card4D_target_x = 10'd107;
reg [9:0]card4D_target_y = 10'd26;

reg [9:0]card5D_target_x = 10'd36;
reg [9:0]card5D_target_y = 10'd26;


// card x and y values
reg [8:0]card_asset_x = 9'd15;
reg [8:0]card_asset_y = 9'd19;

// chip x and y values
reg [8:0]chip_asset_x = 9'd0;
reg [8:0]chip_asset_y = 9'd0;


/* this is where I'm adding the x, y coordinates of the dealer's chips */

reg [9:0]chip1D_target_x = 10'd7;
reg [9:0]chip1D_target_y = 10'd32;

reg [9:0]chip2D_target_x = 10'd9;
reg [9:0]chip2D_target_y = 10'd45;

reg [9:0]chip3D_target_x = 10'd13;
reg [9:0]chip3D_target_y = 10'd58;

reg [9:0]chip4D_target_x = 10'd19;
reg [9:0]chip4D_target_y = 10'd71;

reg [9:0]chip5D_target_x = 10'd25;
reg [9:0]chip5D_target_y = 10'd84;



/* this is where I'm adding the x, y coordingate of the player's chips */

reg [9:0]chip1P_target_x = 10'd141;
reg [9:0]chip1P_target_y = 10'd32;

reg [9:0]chip2P_target_x = 10'd139;
reg [9:0]chip2P_target_y = 10'd45;

reg [9:0]chip3P_target_x = 10'd135;
reg [9:0]chip3P_target_y = 10'd58;

reg [9:0]chip4P_target_x = 10'd129;
reg [9:0]chip4P_target_y = 10'd71;

reg [9:0]chip5P_target_x = 10'd123;
reg [9:0]chip5P_target_y = 10'd84;



// variable that can be set to high to start the FSM that reads from the ROM and writes it to the RAM
reg start_asset;


/* I wanted to find some kind of way that I could keep track of everything that is happening
with the cards that are in hand that would allow me to change which asset I'm writing to the Ram
so I settled on the idea of basically just having a counter which is probably not the best solution
but it tends to be the first thing I try */

reg [2:0] player_hand_size = 3'd0; //should have a max of 5 for both player and dealer hand
reg [2:0] dealer_hand_size = 3'd0;

reg [2:0] player_chip_size = 3'd0; //decided to have the same naming conv for chips, should also be <= 5
reg [2:0] dealer_chip_size = 3'd0;



wire en_card;
wire [14:0]the_vga_draw_frame_write_mem_address;
wire [23:0]the_vga_draw_frame_write_mem_data;


asset_controller my_asset_controller(
	.clk(clk),
	.rst(rst),

	// starting the fsm - Walker
	.start(start_asset),


	// variables for the fsm - Walker
	.the_vga_draw_frame_write_mem_address(the_vga_draw_frame_write_mem_address),
	.the_vga_draw_frame_write_mem_data(the_vga_draw_frame_write_mem_data),
	
	.en_card(en_card),
	
	.target_x(target_x),
	.target_y(target_y),
	
	.asset_assign_x(asset_x),
	.asset_assign_y(asset_y)

);

vga_frame_driver my_frame_driver(
	.clk(clk),
	.rst(rst),

	.active_pixels(active_pixels),
	.frame_done(frame_done),

	.x(x),
	.y(y),

	.VGA_BLANK_N(VGA_BLANK_N),
	.VGA_CLK(VGA_CLK),
	.VGA_HS(VGA_HS),
	.VGA_SYNC_N(VGA_SYNC_N),
	.VGA_VS(VGA_VS),
	.VGA_B(VGA_B),
	.VGA_G(VGA_G),
	.VGA_R(VGA_R),

	/* writes to the frame buf - you need to figure out how x and y or other details provide a translation */
	.the_vga_draw_frame_write_mem_address(the_vga_draw_frame_write_mem_address),
	.the_vga_draw_frame_write_mem_data(the_vga_draw_frame_write_mem_data),
	.the_vga_draw_frame_write_a_pixel(en_card)
);


/* The logic for the blackjack project */




always@(*)
	begin
		
		if (KEY[1] == 0)
			begin
				if(player_hand_size == 0)
					begin
						target_x = card1P_target_x;
						target_y = card1P_target_y;
					end
				
				else if(player_hand_size == 1)
					begin
						target_x = card2P_target_x;
						target_y = card2P_target_y;
					end
					
				asset_x = card_asset_x;
				asset_y = card_asset_y;
				start_asset = 0;
			end
			
		else
			start_asset = 1;
		
	end







endmodule